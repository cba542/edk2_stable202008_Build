/*
 * Copyright (c) 2019, Linaro Limited
 *
 * SPDX-License-Identifier: BSD-2-Clause-Patent
 */

#define LITTLEENDIAN 1
#define INLINE static inline
#define SOFTFLOAT_BUILTIN_CLZ 1
#define SOFTFLOAT_FAST_INT64
#include "opts-GCC.h"
